﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class ReadingFile
    {
        #region Private Variables
        private ConsoleLogger _logger = new ConsoleLogger();
        #endregion

        #region Methods
        public string[] readFile(string searchTerm, string filePath, int positonofsearchterm)
        {
            positonofsearchterm--;
            string[] filenotfound = { "Entered data not found" };
            try
            {
                string[] lines = System.IO.File.ReadAllLines(filePath);
                for(int i =0; i<lines.Length; i++)
                {
                    string[] fields = lines[i].Split(',');
                    if(fileMatches(searchTerm, fields, positonofsearchterm))
                    {
                        _logger.Write("Selection Done");
                        return fields;
                    }
                }
                return filenotfound;
            }
            catch(Exception ex)
            {
                _logger.Write("Entered data not found"+ ex.Message);
                return filenotfound;
            }
        }

        public static bool fileMatches(string searchTerm, string[] file, int positionOfSearchItem)
        {
            if(file[positionOfSearchItem].Equals(searchTerm))
            {
                return true;
            }
            return false;
        }
        #endregion
    }
}

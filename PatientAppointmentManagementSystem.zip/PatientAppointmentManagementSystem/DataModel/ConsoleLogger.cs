﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class ConsoleLogger:ILogger
    {
        #region Methods
        public void Write(string msg)
        {
            Console.WriteLine(msg);
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class DataValidator
    {
        #region Private members
        ConsoleLogger _logger = new ConsoleLogger();
        #endregion

        #region Methods
        public bool PatientInfoDataValidator(string mrn, string email, string name, string contactNumber)
        {
            if (string.IsNullOrEmpty(mrn))
            {
                _logger.Write("MRN Invalid");
            }
            if(string.IsNullOrEmpty(name))
            {
                _logger.Write("Name Invalid");
            }
            if(string.IsNullOrEmpty(email))
            {
                _logger.Write("Email Invalid");
            }
            if(string.IsNullOrEmpty(contactNumber))
            {
                _logger.Write("Phone Number Invalid");
            }
            return false;
        }
        #endregion
    }
}

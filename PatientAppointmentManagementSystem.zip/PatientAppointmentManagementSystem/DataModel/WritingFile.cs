﻿using System;
using System.Collections.Generic;

namespace DataModel
{
    public class WritingFile
    {
        #region Private Variables
        private System.IO.TextWriter writer = Console.Out;
        #endregion

        #region Methods
        public void WritingDataToAFile(string path, List<string> input )
        {
            using (System.IO.StreamWriter fileOutput = new System.IO.StreamWriter(@path, true))
            {
                Console.SetOut(fileOutput);
                Console.SetOut(writer);
                for(int i=0;i<input.Count;i++)
                {
                    fileOutput.Write(input[i] + ",");
                }
                fileOutput.WriteLine();
                fileOutput.Close();
            }
        }
        #endregion
    }
}

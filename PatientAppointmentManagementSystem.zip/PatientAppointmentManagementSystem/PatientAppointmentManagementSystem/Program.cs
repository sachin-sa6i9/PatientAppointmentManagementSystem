﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientAppointmentManagementSystem
{
    class Program
    {
        private DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();
        static void Main(string[] args)
        {
            DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();

            Login login = new Login();
            login.LoginMethod();

            PatientInfoModel.PatientData patientData = new PatientInfoModel.PatientData();
            patientData.PatientInfo();

            PatientRegistrationModel.RegistringPatient registringPatient = new PatientRegistrationModel.RegistringPatient();
            registringPatient.PatientRegistration();

            NotificationDashboardModel.NotificationModel _notification = new NotificationDashboardModel.NotificationModel();
            _logger.Write("\n" + "If you want to send notification type y if no type n");
            string selection = Console.ReadLine();
            if (selection == "y")
            {
                Console.ReadKey();
                _notification.SimulateOnButtonClickEvent();
            }
            if (selection == "n")
            {
                _logger.Write("\n" + "Notifications are not sent");
            }

            NotificationDashboardModel.Dashboard dashboard = new NotificationDashboardModel.Dashboard();

            login.Logout();
        }
    }
}

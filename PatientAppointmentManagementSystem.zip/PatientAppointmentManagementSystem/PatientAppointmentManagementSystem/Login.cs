﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PatientAppointmentManagementSystem
{
    /// <summary>
    /// Class for login page for management system
    /// </summary>
    public class Login
    {
        //public event System.Windows.ExitEventArgs Exit;
        #region Private variables
        private int attempts;
        private DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();
        #endregion

        #region Methods
        /// <summary>
        /// Method for logging in the management console app
        /// </summary>
        public void LoginMethod()
        {
            for(int i=0; i<3; i++)
            {
                _logger.Write("Enter User Name");
                string userName = Console.ReadLine();
                _logger.Write("\n" + "Enter Password");
                string password = Console.ReadLine();

                if (userName != "qqqq" || password != "qqqq")
                {
                    attempts++;
                    _logger.Write("\n" + "Login Failure");
                }
                else
                {
                    _logger.Write("\n" + "Login Successfull");
                    break;
                }
                if(attempts>2)
                {
                    throw new Exception("Failed Attempts 3 times");
                }
            }
        }

        public void Logout()
        {
            _logger.Write("To logout type logout");
            string text = Console.ReadLine();

            if (text == "logout")
            {
                _logger.Write("You are successfully logged out from the application :)");
            }
        }
        #endregion
    }
}

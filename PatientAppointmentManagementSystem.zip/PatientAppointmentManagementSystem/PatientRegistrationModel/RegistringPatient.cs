﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistrationModel
{
    public class RegistringPatient
    {
        #region Private variables
        DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();
        DataModel.ReadingFile readFile = new DataModel.ReadingFile();
        DataModel.WritingFile writeInFile = new DataModel.WritingFile();
        PatientInfoModel.PatientData data = new PatientInfoModel.PatientData();
        private DateAndTime dateAndTime = new DateAndTime();
        private string patientDataPath = @"..\..\..\DataModel\Resources\PatientInfo.csv";
        private string doctorAndDepartmentDataPath = @"..\..\..\DataModel\Resources\Doctors_Departments.csv";
        private string registerdPatientDataFile = @"..\..\..\DataModel\Resources\Registerd_Patient_Data.csv";
        private List<string> inputData = new List<string>();
        #endregion

        #region Constructors
        #endregion

        #region Methods
        public void PatientRegistration()
        {
            _logger.Write("\n"+"Please Enter the MRN Id of the patient to set an appointment");
            string mrn = Console.ReadLine();
            string[] patientInfo = readFile.readFile(mrn, patientDataPath, 1);
            List<string> registrationData = patientInfo.ToList();

            _logger.Write("\n" + "Please select the doctor by entering his or her name else press enter");
            string doctorName = Console.ReadLine();
            string[] doctorInfo = readFile.readFile(doctorName, doctorAndDepartmentDataPath, 1);
            List<string> dData = doctorInfo.ToList();

            var timeAndDate = dateAndTime.SelectingDateAndTime();
            string dateTime = timeAndDate.ToString("yyyy MM dd, hh:mm:ss");

            registrationData.AddRange(dData);
            registrationData.Add(dateTime);

            if (doctorName != "")
            {
                writeInFile.WritingDataToAFile(registerdPatientDataFile, registrationData);
                _logger.Write("\n" + "Appointment created successfully");
            }
            if (doctorName == "")
            {
                _logger.Write("\n" + "No new appointment created");
            }
        }
        #endregion
    }
}

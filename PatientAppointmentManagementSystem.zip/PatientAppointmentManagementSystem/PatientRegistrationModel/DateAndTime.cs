﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistrationModel
{
    public class DateAndTime
    {
        #region Private variables
        private DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();
        #endregion

        #region Constructors
        #endregion

        #region Methods
        public DateTime SelectingDateAndTime()
        {
            _logger.Write("\n" + "Enter a Date and Time (e.g. 4/19/2020, 03:25:50)");
            DateTime userDateTime;

            if(DateTime.TryParse(Console.ReadLine(), out userDateTime))
            {
                _logger.Write("The Day of the week is:" + userDateTime.DayOfWeek);
            }
            else
            {
                _logger.Write("You have entered an incorrect value");
            }
            return userDateTime;
        }
        #endregion
    }
}

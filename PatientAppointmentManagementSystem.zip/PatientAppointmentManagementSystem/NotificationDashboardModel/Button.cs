﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotificationDashboardModel
{
    public class Button
    {
        public event EventDistributor  ClickEvent = null;

        public void OnClick()
        {
            if(this.ClickEvent != null)
            {
                this.ClickEvent.Invoke();
            }
        }
    }
}

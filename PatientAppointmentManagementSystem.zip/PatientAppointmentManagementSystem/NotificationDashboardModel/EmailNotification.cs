﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotificationDashboardModel
{
    public class EmailNotification
    {
        #region Private Variables
        private DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();
        #endregion

        #region Methods
        public void Send()
        {
            _logger.Write("\n" + "Email Notification Sent");
        }
        #endregion
    }
}

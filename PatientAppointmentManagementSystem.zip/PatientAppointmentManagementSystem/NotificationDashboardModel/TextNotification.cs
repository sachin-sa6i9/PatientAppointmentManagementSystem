﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotificationDashboardModel
{
    class TextNotification
    {
        #region Private variables
        private DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();
        #endregion

        #region Methods
        public void Send()
        {
            _logger.Write("\n" + "Text Notification on Mobile is sent");
        }
        #endregion
    }
}

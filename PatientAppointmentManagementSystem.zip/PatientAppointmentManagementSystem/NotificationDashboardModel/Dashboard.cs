﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NotificationDashboardModel
{
    public class Dashboard
    {
        #region Private variable
        DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();
        DataModel.ReadingFile _readingFile = new DataModel.ReadingFile();
        private string registerdPatientDataFile = @"..\..\..\DataModel\Resources\Registerd_Patient_Data.csv";
        List<string> appointments = new List<string>();
        List<string> _appointments = new List<string>();
        #endregion

        #region Constructor
        public Dashboard()
        {
            _appointments = AppointmentOnSelectedDate();
            AppointmentDateAndTime(_appointments);
        }
        #endregion

        #region Methods
        public List<string> AppointmentDateAndTime(List<string> input)
        {
            appointments.Sort((x,y) => x.IndexOf("7").CompareTo(y.IndexOf("8")));

            return appointments;
        }
        public List<string> AppointmentOnSelectedDate()
        {
            _logger.Write("\n" + "Please type date to see the appontments on that date (e.g. 2020 04 19)" +
                "else press enter todays appointments will be visible");
            string selectedDate = Console.ReadLine();

            string[] lines = System.IO.File.ReadAllLines(registerdPatientDataFile);

            if (selectedDate != "")
            {
                foreach (string line in lines)
                {
                    if (line.Contains(selectedDate))
                    {
                        appointments.Add(line);
                    }
                }
                _logger.Write("\n" + "You have:" + appointments.Count + " appointments today " + " Which are with " +
                    "patients as follows:");
                appointments.ForEach(item => _logger.Write("\n" + item));
                return appointments;
            }
            else
            {
                string today = DateTime.Today.Date.ToString("yyyy MM dd");
                foreach (string line in lines)
                {
                    if (line.Contains(today))
                    {
                        appointments.Add(line);
                    }
                }
                if (appointments.Contains("False"))
                {
                    _logger.Write("\n" + "No appontments today enjoy :)");
                }
                _logger.Write("\n" + "You have:" + appointments.Count + " appointments today " + " Which are with " +
                    "patients as follows:");
                appointments.ForEach(item => _logger.Write("\n" + item));
                return appointments;
            }
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotificationDashboardModel
{
    public delegate void EventDistributor();
    public class NotificationModel
    {
        #region Private variables
        private DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();
        private Button okButton = new Button();
        private EmailNotification _emailNotification = new EmailNotification();
        private TextNotification _textNotification = new TextNotification();
        #endregion

        #region Constructor
        public NotificationModel()
        {
            EventDistributor _handlerRef = new EventDistributor(this.OnOkButtonClick);
            this.okButton.ClickEvent += _handlerRef;

            EventDistributor _tNotificationRef = new EventDistributor(this.OnNextOkButtonClickEvent);
            this.okButton.ClickEvent += _tNotificationRef;
        }
        #endregion

        #region Methods
        public void SimulateOnButtonClickEvent()
        {
            this.okButton.OnClick();
        }
        public void OnOkButtonClick()
        {
            //BeforeEmailNotification();
            this._emailNotification.Send();
        }
        public void OnNextOkButtonClickEvent()
        {
            //BeforeTextNotification();
            this._textNotification.Send();
        }
        #endregion
    }
}

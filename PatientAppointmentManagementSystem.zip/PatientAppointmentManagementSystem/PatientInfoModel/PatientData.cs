﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientInfoModel
{
    public class PatientData
    {
        #region private memebers
        private string _mrn;
        private string _name;
        private string _email;
        private string _phoneNumber;
        private DataModel.ConsoleLogger _logger = new DataModel.ConsoleLogger();
        private DataModel.DataValidator _validator = new DataModel.DataValidator();
        private List<string> patientInfo = new List<string>();
        #endregion

        #region Constructors
        #endregion

        #region Methods
        /// <summary>
        /// Method to write Patient Infromation
        /// </summary>
        public void PatientInfo()
        {
            _logger.Write("\n" + "If you want to enter patient details then type y else press enter");
            string response = Console.ReadLine();

            if (response == "y")
            {
                _logger.Write("\n" + "Enter MRN ID");
                _mrn = Console.ReadLine();
                _logger.Write("\n" + "Enter Patient Name");
                _name = Console.ReadLine();
                _logger.Write("\n" + "Enter Patient Email Id");
                _email = Console.ReadLine();
                _logger.Write("\n" + "Enter Patient Contact Number");
                _phoneNumber = Console.ReadLine();
                patientInfo.Add(_mrn);
                patientInfo.Add(_name);
                patientInfo.Add(_email);
                patientInfo.Add(_phoneNumber);
                _validator.PatientInfoDataValidator(_mrn, _name, _email, _phoneNumber);
                WritingPatientInfoToAFile(patientInfo);
            }
        }

        public void WritingPatientInfoToAFile(List<string> input)
        {
            DataModel.WritingFile data = new DataModel.WritingFile();
            string path = "..\\..\\..\\DataModel\\Resources\\PatientInfo.csv";
            data.WritingDataToAFile(path, input);
        }
        #endregion
    }
}
